client Doc
================

.. module:: client
.. autoclass:: Client
    :members:
facial Doc
================

.. module:: facial_encode


.. module:: facial_re
.. autoclass:: recognise

	
.. module:: facial_capture

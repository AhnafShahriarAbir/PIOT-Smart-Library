About 
==================

Our team has been contacted by the local council library to automate the Library Management 
System (LMS). This system will be used to borrow, return and maintain the backend information. 

We have been tasked create an application for two types of users: library user and library admin. 

In summary, the implementation of this assignment involves the following components: 
    • Python documentation tools such as Sphinx
    • Unit testing in Python
    • Socket Programming
    • Writing your own API using Python’s microframework Flask 
    • AI features such as facial recognition, object detection and Voice detection
    • Programming with Cloud databases and,
    • Selected Software Engineering Project Management/Tools

We also adhere the following requiremnt:
    a. Only Raspberry Pi model 3  be used 
    b. You must use Python 3.* . Older versions must not be used. 
    c. Our git repository: https://github.com/jasco111/PIOT-SMART_LIBRARY.git


For library users: The library user arrives at the reception. It is not manned by any person. The 
RECEPTION PI (RP) provides two options available for logging into the system: 
- using console-based system which allows them to type in the user credentials or, 
- using a facial recognition system 

The user registration is required for the first-time user. Upon registration the details are stored in a 
local database installed on RP. You may use sqlite3 or MySQL. 
Upon logging in, a success message along with the username is sent from RP to the MASTER PI 
(MP) via sockets. 

The user is now presented with another console-based application: 
    - search for book catalogues based on ISBN/Author name/Book name 
    - option for borrowing a book/books 
    - option for returning a book/books 
    - logout 

The business rules for these are described along with the requirements. 
Upon logging out a message is sent via sockets from MP to RP. 

For library admin: This is a separate website application that runs on MP. It can only be accessed 
by admin personnel. For simplicity purposes YOU CAN ASSUME that there is only one admin 
(credentials: username = jaqen, password = hghar). 
Admin website makes use of an API to 
- Add books to catalogue 
- Remove books and 
- Generate a data visualisation report for books borrowed (day and week wise) 

The book database is stored on a cloud environment namely the Google’s GCP IoT platform 
(Google Cloud Platform).

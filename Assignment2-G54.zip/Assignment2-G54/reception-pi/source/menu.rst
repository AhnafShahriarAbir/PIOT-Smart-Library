menu Doc
================

.. module:: menu
.. autoclass:: menu
    :members:



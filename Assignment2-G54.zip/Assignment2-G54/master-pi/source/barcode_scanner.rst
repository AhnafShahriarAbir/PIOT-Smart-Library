barcode scanner Doc
====================

.. module:: barcode_scanner
.. autoclass:: barcode
    :members:
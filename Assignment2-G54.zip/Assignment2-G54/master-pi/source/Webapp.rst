Webapp Doc
================

.. automodule:: Webapp

.. autofunction:: login

.. autofunction:: dashboard

.. autofunction:: insertBook

.. autofunction:: deleteBook

.. autofunction:: dayReport

.. autofunction:: weekReport

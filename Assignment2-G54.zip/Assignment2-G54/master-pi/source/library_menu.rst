library menu Doc
================

.. module:: library_menu
.. autoclass:: library_menu
    :members:
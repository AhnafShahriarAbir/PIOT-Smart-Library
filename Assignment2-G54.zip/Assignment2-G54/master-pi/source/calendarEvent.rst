CalendarEvent Doc
===================

.. module:: calendarEvent
.. autoclass:: CalendarEvent
    :members: